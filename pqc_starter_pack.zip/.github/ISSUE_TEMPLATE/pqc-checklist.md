---
name: "PQC Checklist"
about: "Definition of Done за PQC слоя"
title: "PQC: Definition of Done"
labels: ["pqc","security","enhancement"]
assignees: []
---

> Използвай това issue, за да следиш прогреса по PQC слоя.

<!-- Копие на чеклиста за удобство -->
- [ ] liboqs с KEM+SIG
- [ ] liboqs-python фиксирана версия
- [ ] Алгоритми: ml-dsa-{44,65,87} / ml-kem-{512,768,1024}
- [ ] Формати & canonical JSON
- [ ] KEM команди: genkey / encapsulate / decapsulate
- [ ] SIG команди: genkey / sign / verify
- [ ] hybrid-wrap/unwrap + per-recipient HKDF
- [ ] Тестове (positive & negative)
- [ ] TLS демо с oqsprovider
- [ ] README „PQC режим“
- [ ] CI pipeline
- [ ] Таг `pqc-v1` + changelog
