# PQC Checklist (Definition of Done)

## Основи (build & конфигурация)
- [ ] liboqs компилирано с KEM+SIG (`-DOQS_ENABLE_KEM=ON -DOQS_ENABLE_SIG=ON`)
- [ ] liboqs-python фиксирана версия
- [ ] Алгоритми: ml-dsa-{44,65,87} и ml-kem-{512,768,1024}

## Номенклатура и формати
- [ ] FIPS имена (ml-dsa-XX / ml-kem-XXX) + алиаси (dilithium/kyber)
- [ ] KEM публичен ключ: `.kem.pub.json`
- [ ] KEM секретен ключ: `.kem.sec` (0600 права)
- [ ] Canonical JSON навсякъде

## KEM
- [ ] `kem-genkey`
- [ ] `kem-encapsulate`
- [ ] `kem-decapsulate`

## Подписи
- [ ] `sig-genkey`
- [ ] `sig-sign`
- [ ] `sig-verify`

## Hybrid wrap / unwrap
- [ ] hybrid-wrap: генерира DEK, wrap per-recipient с HKDF(shared)
- [ ] AES-256-GCM: отделен nonce/tag/enc_dek за всеки реципиент
- [ ] Подпис (ML-DSA) върху canonical JSON
- [ ] hybrid-unwrap: verify signature, избира kid, decap, unwrap DEK

## Ключова хигиена
- [ ] Секретни файлове с права 0600 (fail при по-широки)
- [ ] Exit code ≠0 при грешка
- [ ] Human-friendly съобщения + `--quiet`

## Тестове
- [ ] KEM roundtrip за 512/768/1024
- [ ] SIG roundtrip за 44/65/87
- [ ] Hybrid wrap multi-recipient
- [ ] Негативни тестове: подменен aad, ciphertext, signature, kid
- [ ] Бенчове: размери/латентност (по избор)

## TLS демо
- [ ] Docker образ с OpenSSL 3 + oqsprovider
- [ ] Self-signed ML-DSA cert
- [ ] Успешен TLS 1.3 handshake (s_server / s_client)

## Документация
- [ ] README секция “PQC режим”
- [ ] Bundle JSON пример

## CI/CD
- [ ] GitHub Actions билд с тестове
- [ ] Матрица (ml-kem-768 + ml-dsa-44 поне)
- [ ] Nightly full run

## Версиониране
- [ ] Таг `pqc-v1`
- [ ] Changelog с breaking changes
