## PQC режим (кратко)

### KEM (ML-KEM / Kyber)
```bash
foritech kem-genkey --kem ml-kem-768 -o mykey
foritech kem-encapsulate --kem ml-kem-768 --pub mykey.kem.pub.json
foritech kem-decapsulate --kem ml-kem-768 --secret mykey.kem.sec --ciphertext <b64>
```

### Подпис (ML-DSA / Dilithium)
```bash
foritech sig-genkey --sig ml-dsa-44 -o signkey
foritech sig-sign --key signkey.sec --in data.bin > sig.b64
foritech sig-verify --pub signkey.pub --in data.bin --signature $(cat sig.b64)
```

### Hybrid wrap / unwrap
```bash
foritech hybrid-wrap --kem ml-kem-768 --sig ml-dsa-44   --recipients recipients.json --aad "backup:projectX" > bundle.json
```
