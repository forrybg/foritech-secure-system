import os, json, base64, hmac, hashlib
from typing import List, Dict, Tuple
from Crypto.Cipher import AES  # pycryptodome
from .pqc_kem import kem_encapsulate, b64e, b64d

def hkdf_extract(salt: bytes, ikm: bytes, hash=hashlib.sha256) -> bytes:
    return hmac.new(salt or b"\x00"*hash().digest_size, ikm, hash).digest()

def hkdf_expand(prk: bytes, info: bytes, length: int, hash=hashlib.sha256) -> bytes:
    n = (length + hash().digest_size - 1) // hash().digest_size
    okm = b""
    t = b""
    for i in range(1, n+1):
        t = hmac.new(prk, t + info + bytes([i]), hash).digest()
        okm += t
    return okm[:length]

def hkdf(salt: bytes, ikm: bytes, info: bytes, length: int=32) -> bytes:
    prk = hkdf_extract(salt, ikm)
    return hkdf_expand(prk, info, length)

def aes_gcm_encrypt(key: bytes, plaintext: bytes, aad: bytes=b"") -> Tuple[bytes, bytes, bytes]:
    nonce = os.urandom(12)
    c = AES.new(key, AES.MODE_GCM, nonce=nonce)
    c.update(aad)
    enc, tag = c.encrypt_and_digest(plaintext)
    return nonce, enc, tag

def aes_gcm_decrypt(key: bytes, nonce: bytes, enc: bytes, tag: bytes, aad: bytes=b"") -> bytes:
    c = AES.new(key, AES.MODE_GCM, nonce=nonce)
    c.update(aad)
    return c.decrypt_and_verify(enc, tag)

def hybrid_wrap_dek(pubkeys: List[Dict], kem_alg="ml-kem-768", aad_str="", signer=None) -> Dict:
    """
    pubkeys: [{"kid":"ops1","pub_b64":"..."}]
    signer: обект с .sign(data: bytes)->bytes (ML-DSA)
    """
    dek = os.urandom(32)  # 256-bit
    aad = aad_str.encode()
    recipients_out = []

    for r in pubkeys:
        pub = b64d(r["pub_b64"])
        ct, shared = kem_encapsulate(pub, alg=kem_alg)
        # per-recipient KEK чрез HKDF(shared)
        info = b"foritech-mlkem-wrap" + aad
        kek = hkdf(salt=b"", ikm=shared, info=info, length=32)
        nonce, enc_dek, tag = aes_gcm_encrypt(kek, dek, aad=aad)
        recipients_out.append({
            "kid": r["kid"],
            "kem_ciphertext_b64": b64e(ct),
            "kem_pub_b64": r["pub_b64"],
            "nonce_b64": b64e(nonce),
            "tag_b64": b64e(tag),
            "enc_dek_b64": b64e(enc_dek)
        })

    bundle = {
        "version": 1,
        "sig_alg": getattr(signer, "alg", None) or "ml-dsa-44",
        "kem_alg": kem_alg,
        "cipher": "AES-256-GCM",
        "aad": aad_str,
        "recipients": recipients_out
    }

    if signer is not None:
        to_sign = json.dumps(bundle, separators=(",", ":"), sort_keys=True).encode()
        signature = signer.sign(to_sign)
        bundle["signature_b64"] = b64e(signature)

    return bundle
