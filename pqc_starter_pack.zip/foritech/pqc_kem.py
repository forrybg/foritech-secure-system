import base64
from oqs import KeyEncapsulation

ALG_ALIASES = {
    "kyber512": "ml-kem-512",
    "kyber768": "ml-kem-768",
    "kyber1024": "ml-kem-1024",
}

def _norm_alg(alg: str) -> str:
    alg = alg.lower()
    return ALG_ALIASES.get(alg, alg)

def kem_generate(alg: str = "ml-kem-768"):
    alg = _norm_alg(alg)
    with KeyEncapsulation(alg) as kem:
        pub = kem.generate_keypair()
        sec = kem.export_secret_key()
    return pub, sec

def kem_encapsulate(pub_b: bytes, alg: str = "ml-kem-768"):
    alg = _norm_alg(alg)
    with KeyEncapsulation(alg) as kem:
        kem.import_public_key(pub_b)
        ct, shared = kem.encap_secret()
    return ct, shared

def kem_decapsulate(ct_b: bytes, sec_b: bytes, alg: str = "ml-kem-768"):
    alg = _norm_alg(alg)
    with KeyEncapsulation(alg) as kem:
        kem.import_secret_key(sec_b)
        shared = kem.decap_secret(ct_b)
    return shared

def b64e(x: bytes) -> str:
    return base64.b64encode(x).decode("ascii")

def b64d(s: str) -> bytes:
    return base64.b64decode(s.encode("ascii"))
