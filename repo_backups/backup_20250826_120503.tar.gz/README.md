# Foritech

Скелет за стабилен SDK/API и CLI.

## CI
![CI • 3.12](https://github.com/forrybg/foritech-secure-system/actions/workflows/ci.yml/badge.svg)
![CI • Lite](https://github.com/forrybg/foritech-secure-system/actions/workflows/ci-lite.yml/badge.svg)
